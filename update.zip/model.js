//Backbone Model

var Blog = Backbone.Model.extend({

    defaults:{
        author: '',
        title: '',
        url: ''
    }
});

Blogs = Backbone.Collection.extend({

});

var blog1 = new Blog({
    author: " Abhishek ",
    title: "Abhishek Blog ",
    url: "www.bandebuche.com"
});

var blog2 = new Blog({
    author: " Suyog ",
    title: "Suyog Blog ",
    url: "www.sbandebuche.com"
});

var blog3 = new Blog({
    author: " Madan ",
    title: "Madan Blog ",
    url: "www.bandebuche"
});

var blogs = new Blogs();